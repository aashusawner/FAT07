class AtoZ
{
   public static void main(String args[])
   {
        
        int i;
        for(i='A';i<='Z';i++)
        {
            
             System.out.println(i);
             
        } 

   }

}